package com.pms.dao;

public class BookingDAO {

}
