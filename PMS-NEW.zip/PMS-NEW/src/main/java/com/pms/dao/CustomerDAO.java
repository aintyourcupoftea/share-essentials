package com.pms.dao;

public class CustomerDAO {

}
