package com.pms.model;

public class Customer {

}
