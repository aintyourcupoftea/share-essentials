package com.pms.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.UUID;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import com.pms.util.DBConnection;

/**
 * Servlet implementation class RegisterServlet
 */
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");

	      
        String name = req.getParameter("name");
        String email = req.getParameter("email");
        String code = req.getParameter("code");
        String mob = req.getParameter("mobile");
        String add = req.getParameter("address");
//        String userId = req.getParameter("userid");
        String pass = req.getParameter("password");
        String confirmPass = req.getParameter("confirm-password");
        String pref = req.getParameter("preferences");

       System.out.println(name);
       System.out.println(email);
       System.out.println(code);
       System.out.println(mob);
       System.out.println(add);
//       System.out.println(userId);
       System.out.println(pass);
       System.out.println(pref);
//
        // Validate password and confirm password match
        if (!pass.equals(confirmPass)) {
            res.getWriter().write("Passwords do not match!");
            return;
        }

        // Password security checks
        if (pass.length() < 8) {
            res.getWriter().write("Password must be at least 8 characters long!");
            return;
        }

        // Generate random username
        String randomUsername = UUID.randomUUID().toString().replace("-", "").substring(0, 10);

        // Encrypt password
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        String hashedPass = encoder.encode(pass);

        try (Connection con = DBConnection.connect()) { // Ensure connection is closed
            if (con == null) {
                res.getWriter().write("Database connection failed!");
                return;
            }

            // Insert into database
            String sql = "INSERT INTO Customer_Registration (Username, CustomerName, Email, Code, Mobno, Address, Password, Preferance) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement ps = con.prepareStatement(sql)) { // Ensure PreparedStatement is closed
                ps.setString(1, randomUsername);
                ps.setString(2, name);
                ps.setString(3, email);
                ps.setString(4, code);
                ps.setString(5, mob);
                ps.setString(6, add);
                ps.setString(7, hashedPass);
                ps.setString(8, pref);

                int r = ps.executeUpdate();
                HttpSession session = req.getSession();
                if (r > 0) {
                	//req.se
                    res.getWriter().write("Registration Successful! Your username: " + randomUsername);
                    
                    req.setAttribute("msg", "registration successful");
                    req.setAttribute("username",randomUsername);
                    System.out.println(randomUsername);
                    req.getRequestDispatcher("CustomerLogin.jsp").forward(req, res);
                } else {
                    res.getWriter().write("Registration Failed! Please try again.");
                }
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            res.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database Error: " + e.getMessage());
        }
	}

}
