package com.pms.controller;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.pms.util.DBConnection;


/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html"); // Ensure proper response type
        PrintWriter out = res.getWriter();
        
        String username = req.getParameter("username");
        String password = req.getParameter("password"); // From HTML
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        
        try {
            Connection con = DBConnection.connect();
            if (con != null) {
                String sql = "SELECT Username, Password FROM Customer_Registration WHERE Username=?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, username);
                ResultSet rs = ps.executeQuery();

                
                if (rs.next()) {
                    String hashpass = rs.getString("Password"); // From DB
            
                   // String customerName=rs.getString("CustomerName");
                   
                
                    if (encoder.matches(password, hashpass)) {
                   
                        HttpSession session = req.getSession();
                        session.setAttribute("username", username);
                        session.setMaxInactiveInterval(60*60); 
                        res.sendRedirect("customer/DashBoard.jsp");
                    } else {
                       
                        out.println("<script>alert('Incorrect Password!'); window.location.href='CustomerLogin.jsp';</script>");
                    }
                } else {
               
                    out.println("<script>alert('Username Not Found!'); window.location.href='CustomerLogin.jsp';</script>");
                }
            } else {
                out.println("<script>alert('Database Connection Error!'); window.location.href='CustomerLogin.jsp';</script>");
            }
        } catch (Exception e) {
            e.printStackTrace();
            out.println("<script>alert('Something Went Wrong!'); window.location.href='CustomerLogin.jsp';</script>");
        }
	}

}
